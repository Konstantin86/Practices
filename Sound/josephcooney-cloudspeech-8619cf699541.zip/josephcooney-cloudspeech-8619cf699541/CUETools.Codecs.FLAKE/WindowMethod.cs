﻿namespace CUETools.Codecs.FLAKE
{
    public enum WindowMethod
    {
        Estimate = 0,
        Evaluate = 1,
        Search = 2
    }
}
