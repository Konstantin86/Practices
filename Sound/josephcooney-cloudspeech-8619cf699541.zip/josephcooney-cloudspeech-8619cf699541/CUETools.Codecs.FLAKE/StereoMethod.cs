﻿
namespace CUETools.Codecs.FLAKE
{
	public enum StereoMethod
	{
		Independent = 0,
		Estimate = 1,
		Evaluate = 2,
		Search = 3
	}
}
