﻿namespace CUETools.Codecs.FLAKE
{
    public struct SeekPoint
    {
        public long number;
        public long offset;
        public int framesize;
    }
}
