﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace CloudSpeech.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            var stt = new SpeechToText();
            using (var stream = new FileStream(@"c:\sandbox\cloudspeech\this_is_a_test.wav", FileMode.Open))
            {
                var response = stt.Recognize(stream);                
            }
        }
    }
}
