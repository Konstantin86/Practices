namespace DataSorter
{
    public enum Gender
    {
        Male,
        Female
    }
}